/*
 ==========================================================================
 * @Author:        Rachel Thornton
 *  Summary: This class functions as an object that holds all data for a single
    tutor. This object serves as a reference in scheduling tutors for work in
    the writing center as this holds all of their preferred hours in addition
    to keeping track during the schedule making process of how many hours they
    have been scheduled in order to prevent them from being overscheduled.
==================================================================
 */
package scheduler;

public class Tutor {
    private String _firstName;
    private String _lastName;
    private String _gradClass;
    private String _studentID;
    private boolean _wantsClass;    //if the tutor would like to be paired with a class
    private boolean _wantsCenterHours;  //if a tutor would like to work in the writing center
    private boolean _hasMaxHours; //if a tutor has been placed into the schedule twice this becomes true and they can no longer be scheduled.
    private int _hourCounter;   //number of hours a tutor has within the schedule, will be incremented as they are scheduled and used to set _hasMaxHours
    
    //preferences 1-10 topmost preference being first and chronologically going
    //down to their least preferred. Everyone is required to have 10 preferences,
    //but this could be altered depending on if the user desires more of less
    //preferences per person.
    private String[] _preferences = new String[10]; 
    
    //preferences timeshg
    //list of instructors they DON'T want
    
    /*
    *   This constructor creates a tutor object with a first and last name, graduation year,
    *   student ID, two booleans determining where and how they would like to work,
    *   and a list of preferences of which hours they would like to work within
    *   the writing center.
    */
    public Tutor(String fname, String lname, String gradClass, String sID, 
                 boolean ifclass, boolean ifcenter, String[] prefs)
    {
        _firstName = fname;
        _lastName = lname;
        _gradClass = gradClass;
        _studentID = sID;
       _wantsClass = ifclass;
        _wantsCenterHours = ifcenter;
        _preferences = prefs;
        _hourCounter = 0;
       
        if(_wantsClass)
            _hasMaxHours = false;
    }
    
    /*
    * This sets _hasMaxHours to true if the tutor has been scheduled for 2 hours
    * in the writing center already, so that they cannot be scheduled anymore.
    * This is a private method as this will only be set once a tutor has been
    * scheduled twice and therefore is only called from incrimentHours.
    */
    private void setMaxHours()
    {
        _hasMaxHours = true;
    }
    
    /*
    *   This is a getter method that returns the number of hours a tutor has been scheduled
    */
    public int getHours(){
        return _hourCounter;
    }
    
    /*
    *   This is a setter method that increments the _hourCounter which tracks how
    *   many hours the student has been scheduled. The current maximum is two and
    *   this limit has been established in the code, once a student has been
    *   scheduled for two hours the maximum hours boolean is changed to true,
    *   and a tutor may no longer be scheduled.
    */
    public void incrimentHours(){
        _hourCounter +=1;
        if(_hourCounter >= 2)
            setMaxHours();
    }
    
    /*
    *   This is a getter method that returns a boolean that will be true if the
    *   student has been scheduled the maximum number of hours they can be, or
    *   false if they are still able to be scheduled.
    */
    public boolean hasHours()
    {
        return _hasMaxHours;
    }
    
    /*
    * This will set the array at index i (ie preference i) with p which is the 
    * time and day preference for that numbered preference. This allows preferences
    * to be modified within the code, though they will not be reflected in the
    * database unless separately changed there.
    */
    public void setPreference(int i, String p)
    {
        _preferences[i] = p;
    }
    
    /*
    * This is a getter method that returns the first and last name of the student
    */
    public String returnName()
    {
        return _firstName + " " + _lastName;
    }
    
    /*
    * This will return the preference at index i. This is assuming that the 
    * function creating the schedule is incrementing throughout preferences and
    * will cycle through each level of preference as needed.
    */
    /*
    * This is assuming a String format for preference of "int char" where the int
    * is an integer from 9-23 and char is a character for Monday (M), Tuesday (T),
    * Wednesday (W), Thursday (Z), and Friday (F)
    */
    public int readPreferenceTime(int i)
    {
        String[] s = _preferences[i].split(" ");
        //System.out.println("------");
        //System.out.println(s[0]);
        return Integer.parseInt(s[1]);
    }
    
   
    /*
    * This is assuming a String format for preference of "int char" where the int
    * is an integer from 9-23 and char is a character for Monday (M), Tuesday (T),
    * Wednesday (W), Thursday (Z), and Friday (F)
    */
    public String readPreferenceDay(int i)
    {
        String[] s = _preferences[i].split(" ");
        return s[0];
    }
    
    /*
    *   This is a getter method that returns the student's studentID. This is 
    *   used to compare Tutor objects quickly as all students have a unique
    *   student ID
    */
    public String getStudentID()
    {
        return _studentID;
    }
    
    
}

