/*
 ==========================================================================
 * @Author:        Rachel Thornton + Sean Bennett 
 * Class:
 * Assignment: 
Summary: 
==================================================================
 */
package scheduler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.*;

import java.util.Scanner;

public class Scheduler {

    //we live on the edge with magic numbers now
    private static SessionTime[] _monday = new SessionTime[14];
    private static SessionTime[] _tuesday = new SessionTime[14];
    private static SessionTime[] _wednesday = new SessionTime[14];
    private static SessionTime[] _thursday = new SessionTime[14];
    private static SessionTime[] _friday = new SessionTime[14];
    //only if needed will center be open on weekends
    //  SessionTime[] saturday = new SessionTime[14];
    //  SessionTime[] sunday = new SessionTime[14];

    //this holds all tutor objects with their availability
    private static ArrayList<Tutor> _tutors = new ArrayList<Tutor>(); 
    
    //these are for connecting to the database
    private static Connection conn;
    private static Statement stmt;

    /**
     * @param args the command line arguments
     * This is the main method of the program,  it begins by establishing a
     * connection to the database and then populates both the _tutors arraylist
     * and SessionTime arrays for each weekday. The schedule is then created
     * using makeSchedule and displayed to the console using printSchedule().
     */
    public static void main(String[] args) throws SQLException {
        establishConnectionToDatabase();
        stmt = conn.createStatement();
        popTutor();
        populateSessionTime(9); //where 9 is openining for the center and will 
        //increment until closing at 10pm
        //  populateTutors();

        runProgram();
          
        stmt.close();
        conn.close();
    }
    
    /*
    *   This method creates an interface within the console that interacts with the user, 
    *   prompting them for letter commands and displaying data depending on the
    *   command.
    */
    public static void runProgram()
    {
        System.out.println("Welcome to the Scheduler!");
        Scanner in = new Scanner(System.in);
        String userInput = "";
        do
        {
            System.out.println();
            System.out.println("Please enter any of the following letters for their corresponding command");
            System.out.println("Please note that S should be run first for most other commands to work, D is a permanent deletion, and C clears the entire schedule.");
            System.out.println("Q for quit.");
            System.out.println("S to create a schedule");
            System.out.println("P to print the schedule");
           //System.out.println("H to calculate the hours for the center.");
           //System.out.println("W to change a specific writing fellow's status within the center to active/inactive.");
           System.out.println("T to display all writing fellows with availability at a certain time.");
            System.out.println("D to delete a tutor from the database");
            System.out.println("C to clear the schedule.");
            //System.out.println("U will update something yet undetermined");
            
            userInput = in.nextLine();
            userInput = userInput.toUpperCase();
            switch(userInput)
            {
                case "Q": //breaks the switch loop and should quit the program entirely
                    break;
                case "S":   //creates the schedule, all SessionTimes should be populated with tutors
                    makeSchedule();
                    break;
                case "P":   //Prints schedule
                    printSchedule(_monday);
                    printSchedule(_tuesday);
                    printSchedule(_wednesday);
                    printSchedule(_thursday);
                    printSchedule(_friday);
                    break;
                case "H":
                    break;
                case "W":
                    break;
                case "T": //searches for all tutors at day + time and displays them
                    System.out.println("Please enter the day of the week");
                    String day = in.nextLine();
                    System.out.println("Please enter the time using this format: 9 PM");
                    String time = in.nextLine();
                    displayPref(day, time);
                    break;
                case "D": //deletes a given tutor from the database
                    deleteTutor(in); //curretly doesn't work
                    break;
                case "C": //clears shift table but does not delete the table
                            //should not clear corresponding sessiontimes in java program? Or should?
                    clearSchedule();
                    break;
                case "U": //update statement required for database project
                    break;
                default:
                    System.out.println("That's not a valid command, please enter another letter");
                    break; 
            }
        }
        while(!userInput.equals("Q"));   
    }
    
    public static void clearSchedule()
    {
        try
        {
            String sql = "DELETE FROM ScheduleSorterDatabase.Shift ";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            //pstmt.setString(1,deletedCol);
            pstmt.execute();
        }
        catch(SQLException sqle)
        {
            System.out.println("Error deleting tutors from schedule. Was schedule created first?");
        }
    }
    
    /*
    *   This displays all tutors with a preference of a specific day and time
    */
    public static void displayPref( String day, String time)
    {
        //query using select to get all tutors with the preference at specific day
        //and time
        try{
        String sql = "SELECT t.FirstName, t.LastName FROM SceduleSorterDatabase.dbo.Tutor t WHERE t.FirstPref = '" + 
                day +" "+ time + "' OR t.SecondPref = '" + day + " " + time + "' OR t.ThirdPref= '" +
                day + " " + time + "' OR t.FourthPref = '" + day + " " + time + "' OR t.FifthPref = '" +
                day + " " + time + "' OR t.SixthPref = '" + day + " " + time + "' OR t.SeventhPref = '" +
                day + " " + time + "' OR t.EighthPref = '" + day + " " + time + "' OR t.NinethPref = '" +
                day + " " + time + "' OR t.TenthPref = '" + day + " " + time + "'";
                
        ResultSet rs = executeQueryStatement(sql);
        displayQueryResults(rs);
        }
        catch(SQLException sqle)
        {
            System.out.println("Error in comparing preferences to tutors. Are time and date valid?");
        }
        
    }
	
    
    /*
    *   This will delete a singule tutor from the database given the student's
    *   studentID, which is unique for every single student.
    */
    public static void deleteTutor(Scanner in)
    {
        System.out.println("Please give the student ID of the student you wish to delete: ");
        String userInput = in.nextLine();
        
        try
        {
        String sql = "DELETE FROM [ScheduleSorterDatabase].[dbo].[Tutor] WHERE [ScheduleSorterDatabase].[dbo].[StudentID] = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, userInput);
        pstmt.execute();
        System.out.println("Student successfully deleted :) ");
        }
        catch(SQLException sqle)
        {
            sqle.printStackTrace();
            System.out.println("SQL Error. Please check to make sure the student ID matches a student that exists.");
        }
        
    }

    /*
    *   This method accesses the database through querying the Tutor table, which
    *   stores all the information from the tutor about themselves and their work
    *   preferences. This is all taken and stored in the tutor class for easy access
    *   in order to create the schedule.
    */
    public static void popTutor() throws SQLException {
        String studentID ="", firstName="", lastName="", 
                classOf="", firstPref="", secondPref="", 
                thirdPref="", fourthPref="", fifthPref="", sixthPref="", seventhPref="",
                eighthPref="", ninethPref="", tenthPref="";
        
        boolean ifClass=false, ifCenter=false;
        
        String query = "Select * FROM [ScheduleSorterDatabase].[dbo].Tutor";
        ResultSet rs = stmt.executeQuery(query);
        ResultSetMetaData rsmd = rs.getMetaData();
       
        int numCol = rsmd.getColumnCount();
        
        while (rs.next()) { //while there is another row within the database the
                            //following will happen
                            
            for (int i = 1; i < numCol-1; i++) { //iterates through each column
                String columnVal = rs.getString(i); //value from column
                //System.out.println(rsmd.getColumnName(i) + ": " + columnVal);
                if(i == 1)
                {
                    studentID = columnVal; //sets student ID
                    //System.out.println(studentID);
                }    
                else if(i == 2)
                {
                    firstName = columnVal; //sets student first name
                }
                else if(i== 3)
                {
                    lastName = columnVal; //sets student last name
                }
                else if(i == 4)
                {
                    classOf = columnVal; //sets graduation year
                }
                else if(i == 5)
                { //sets booleans depending on if a student wants to work
                    //in the writing center, be paired with a class, or both
                    String [] v = columnVal.split(",");
                    String center = v[0];
                    String clas = "";
                    if(v.length > 1)
                      clas = v[1];
    
                    if(center.equals("Writing Center"))
                        ifCenter = true;
                    if(clas.equals("Class"))
                        ifClass = true;
                    
                }
                else if(i==6)
                { //converts time to military time and then sets preferences
                    String temp = convertingTime(columnVal);
                    firstPref = temp;
                }
                else if(i == 7)
                {
                    String temp = convertingTime(columnVal);
                    secondPref = temp;
                }
                else if( i == 8)
                {
                    String temp = convertingTime(columnVal);
                    thirdPref = temp;
                }
                else if (i == 9)
                {
                   String temp = convertingTime(columnVal);
                    fourthPref = temp;
                }
                else if(i == 10)
                {
                    String temp = convertingTime(columnVal);
                    fifthPref = temp;
                }
                else if( i == 11)
                {
                    String temp = convertingTime(columnVal);
                    sixthPref = temp;
                }
                else if( i == 12)
                {
                    String temp = convertingTime(columnVal);
                    seventhPref = temp;
                }
                else if(i == 13)
                {
                    String temp = convertingTime(columnVal);
                    eighthPref = temp;
                }
                else if(i == 14)
                {
                    String temp = convertingTime(columnVal);
                    ninethPref = temp;
                }
                else if(i == 15)
                {
                    String temp = convertingTime(columnVal);
                    tenthPref = temp;
                }
                else
                {
                    System.out.println("This Error");
                }
               
            }
             String[] tempP = {firstPref, secondPref, thirdPref, fourthPref,
                fifthPref, sixthPref, seventhPref, eighthPref, ninethPref, tenthPref};
             //creates an array of preferences to be stored in tutor and easily
             //accessed later for scheduling purposes
             
            _tutors.add(new Tutor(firstName, lastName, classOf, studentID,
                        ifClass, ifCenter, tempP)); //adds tutor to arraylist
           
        }
    }
    
    /*
    *   This method parses a string s, splitting it on the spaces and then getting
    *   the preference time from the second position in the array. This is then
    *   converted into an integer and if the third position has "PM" then twelve
    *   is added to the integer to convert it to military time. The preference
    *   is then returned as a string of weekday space time in military time. 
    */
    public static String convertingTime(String s)
    {
       String [] times = s.split(" ");
       int n = Integer.parseInt(times[1]); //holds time from preference as int
       if(times[2].equals("PM"))
       {
           n+=12;//military time conversion
       } 
      return times[0] + " " + n + " "; //converts back to a string
    }

    /*
    *   This method establishes a connection to a database. Specifically, this
    *   is connecting to a server on another laptop using the username and password
    *   to access the database system on that laptop.
    */
    private static void establishConnectionToDatabase() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionUrl = "jdbc:sqlserver://localhost;integratedSecurity=true;"; //to port into database connected to form use: jdbc:sqlserver://LAPTOP-KDOCU5C4;username=Sean;password=001122;
            conn = DriverManager.getConnection(connectionUrl);
        } catch (ClassNotFoundException | SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /*
    *   This gets a resultset from querying the database and returns the 
    *   ResultSet with the results of the query in the resultset.
    */
    private static ResultSet executeQueryStatement(String s) throws SQLException {
        ResultSet rs;
        rs = stmt.executeQuery(s);
        return rs;
    }

    /*
    *   This calls getSchedule five times, one for each weekday, in order to
    *   create the schedule for each day. This is separated by weekday to
    *   accomodate for potentially flucuating hours per weekday.
    */
    private static void makeSchedule() {
        getSchedule(_tutors, _monday);
        getSchedule(_tutors, _tuesday);
        getSchedule(_tutors, _wednesday);
        getSchedule(_tutors, _thursday);
        getSchedule(_tutors, _friday);
    }

    /*
    *   This method iterates ten times, once for each preference. For each preference
    *   this method iterates through all the tutor objections in tutors and then
    *   iterates through each SessionTime in each weekday. If a tutor's preference
    *   matches the current SessionTime time and day of week then it checks to 
    *   see if the SessionTime has an empty spot, as there can only be two tutors
    *   per hour. If there is an empty spot the tutor must also not already be
    *   scheduled the maximum number of hours allowed. 
    */
    private static void getSchedule(ArrayList<Tutor> tutors, SessionTime[] dayOfTheWeek) {
        int shiftID = 1;
        for (int i = 0; i < 10; i++) {
            for (Tutor tutor : tutors) {
                for (SessionTime st : dayOfTheWeek) {
                    if ((tutor.readPreferenceTime(i) == st.getTime()) && (tutor.readPreferenceDay(i).equals(st.getDay()))) {
                        if ((st.getTutors()[0] == null || st.getTutors()[1] == null) && !(tutor.hasHours())) {
                            st.addTutor(tutor);
                            tutor.incrimentHours();
                            
                            //adds a record of every tutors shift into the Shift table in the database
                            try
                            {
                                String sql = "INSERT INTO [ScheduleSorterDatabase].[dbo].[Shift] (ShiftID, DayOfWeek, TimeOfDay, Tutor, Shift_class, Section, submittedby, submitteddtm) VALUES (?,?,?,?,?,?,?,?)";
                                PreparedStatement pstmt = conn.prepareStatement(sql);
                                pstmt.setString(1, shiftID+"");
                                pstmt.setString(2, st.getDay());
                                pstmt.setString(3, st.getTime()+"");
                                pstmt.setString(4, tutor.getStudentID());
                                pstmt.setString(5, "Center");
                                pstmt.setString(6, "Center");
                                pstmt.setString(7, "anon");
                                pstmt.setString(8, "0000");
                                pstmt.execute();
                            }
                            catch(SQLException sqle)
                            {
                                System.out.println("Tutor failed to enter database as a shift");
                            }
                            
                            }
                        }
                    }
                }
            }
        }
                
    
        
    //prints schedule to console until if/when we get a gui/excel sheet/etc
    /*
    *   This prints the schedule in chronological order from Monday through Friday
    *   listing each time and next to that time students that are working, if
    *   any, otherwise there is indication that there is an open shift.
    */
    private static void printSchedule(SessionTime[] dayOfTheWeek) {        
        System.out.println(dayOfTheWeek[0].getDay() + " Schedule: ");
        for (int i = 0; i < dayOfTheWeek.length; i++) {
            int t = dayOfTheWeek[i].getTime();
            if (t == 12){
                System.out.print(t + "PM");
            }
            else if(t > 12)
            {
                t = t-12;
                
                System.out.print(t + "PM");   
            }else
            {
                System.out.print(t + "AM");
            }
            
            System.out.println( " " + dayOfTheWeek[i].getTutorsString());
        }
        
        System.out.println();
    }

    /*
    *   This populates the five arrays that each represent the schedule for one
    *   weekday. The parameter startTime holds the start time for the writing
    *   center, assuming that the start time is the same every weekday. If this
    *   is not true, this method would be able to be modified to reflect the true
    *   opening and closing hours of the writing center.
    */
    private static void populateSessionTime(int startTime) {

        for (int i = 0; i < _monday.length; i++) {
            _monday[i] = new SessionTime(startTime, "Monday");
            _tuesday[i] = new SessionTime(startTime, "Tuesday");
            _wednesday[i] = new SessionTime(startTime, "Wednesday");
            _thursday[i] = new SessionTime(startTime, "Thursday");
            _friday[i] = new SessionTime(startTime, "Friday");
            startTime++;
        }
    }

    private static void displayQueryResults(ResultSet rs) throws SQLException{
       ResultSetMetaData rsmd = rs.getMetaData();
       int numOfCols = rsmd.getColumnCount();
       while(rs.next())
       {
           for(int i = 1; i < numOfCols + 1; i++)
           {
               System.out.print((rsmd.getColumnLabel(i) + ": " + rs.getString(i) + " "));
           }
           System.out.println();
       }
   }
}
