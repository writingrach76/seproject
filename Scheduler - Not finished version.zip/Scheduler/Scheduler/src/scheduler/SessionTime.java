/*
 ==========================================================================
 * @Author:        Rachel Thornton
 
 *  Summary: This class works as an individual one hour time slot within a larger
    schedule. Each object of this class has a singular time(the start of the hour
    of that time slot) and the compatible day of the week. It also has two available
    slots within the schedule for tutors who want to work within the specific time.
    These slots may or may not end up being filled and can be displayed accordingly 
    whether they have been filled or not.
=================================================================
 */
package scheduler;

public class SessionTime 
{
    private int _timeOfDay; //time of day where we use the 24 hour clock -> 
                        //make sure this is also this way in the database
    
    private String _dayOfWeek; //Monday through Friday currently but can be
                                //changed to allow for weekends as well
    
    private Tutor[] _workers = new Tutor[2]; //holds 1-2 tutor objects which
                              //is the 1-2 tutors working in the writing center at this point and time
    
    /*
    *   This constructor creates a SessionTime using time of day and day of the
    *   week, and also establishes an array with two workers for the writing
    *   center, as there can only be a maximum of two workers at a time. (These
    *   values are initialized as null because there can be empty hours within
    *   the center if there is no one with availability at a specific time).
    */
    public SessionTime(int timeOfDay, String dayOfWeek)
    {
        _timeOfDay = timeOfDay;
        _dayOfWeek = dayOfWeek;
        
        _workers[0] = null;
        _workers[1] = null;
    }
    
    /*
    *   This method adds a tutor to work during this session's time. If there
    *   are no workers during this session one is added to the first spot, if
    *   there is already one worker then the tutor is added to the second spot
    *   if it is empty, only after a check is done to ensure that the tutor is
    *   not already working during this session.
    */
    public void addTutor(Tutor tutor)
    {
        if(_workers[0] == null)
            _workers[0] = tutor;
        else if(_workers[0]instanceof Tutor && _workers[1] == null)
        {
            if( !( _workers[0].getStudentID().equals(tutor.getStudentID()) ))
                _workers[1] = tutor;
        }
        else
        {
            //this time slot is full and nothing will happen. Don't need this??
        }
    }
    
    /*
    *   This is a getter method that simply returns a Tutor array of the workers
    *   working in this session. If there are no workers during this time, the
    *   array will have null values.
    */
    public Tutor[] getTutors()
    {
        return _workers;
    }
    
    /*
    *   This is a getter method that returns the workers during this session
    *   as a single string. If there are no workers, None is printed out in each
    *   spot in the schedule, otherwise the tutors names will be printed for
    *   readability.
    */
    public String getTutorsString()
    {
        if(_workers[0] == null && _workers[1] == null)
        {
            return "None" + "   " + "None";
        }
        else if(_workers[0] == null && _workers[1] instanceof Tutor)
        {
            return "None" + "   "+ _workers[1].returnName();
        }
        else if(_workers[0] instanceof Tutor && _workers[1] == null)
        {
            return _workers[0].returnName()+ "   " + "None";
        }
        else
        {
            return _workers[0].returnName() + "    " + _workers[1].returnName();
        }
    }
    
    /*
    *   This is a getter method that returns the current session's time slot
    */
    public int getTime()
    {
        return _timeOfDay;
    }
    
    /*
    *   This is a getter method that returns the day of the week of the current
    *   session.
    */
    public String getDay()
    {
        return _dayOfWeek;
    }
}
